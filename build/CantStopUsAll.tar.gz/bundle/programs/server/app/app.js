var require = meteorInstall({"imports":{"api":{"characteristics":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characteristics/server/publications.js                                                         //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Characteristics = void 0;                                                                                 // 1
module.watch(require("../characteristics.js"), {                                                              // 1
  Characteristics: function (v) {                                                                             // 1
    Characteristics = v;                                                                                      // 1
  }                                                                                                           // 1
}, 1);                                                                                                        // 1
Meteor.publish('characteristics.all', function () {                                                           // 4
  return Characteristics.find();                                                                              // 5
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"characteristics.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characteristics/characteristics.js                                                             //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                       //
                                                                                                              //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                              //
                                                                                                              //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }             //
                                                                                                              //
module.export({                                                                                               // 1
    Characteristics: function () {                                                                            // 1
        return Characteristics;                                                                               // 1
    },                                                                                                        // 1
    CharacteristicsObject: function () {                                                                      // 1
        return CharacteristicsObject;                                                                         // 1
    }                                                                                                         // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
    Mongo: function (v) {                                                                                     // 1
        Mongo = v;                                                                                            // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Characteristics = new Mongo.Collection('characteristics');                                                // 4
                                                                                                              //
var CharacteristicsObject = function () {                                                                     //
    function CharacteristicsObject() {                                                                        //
        (0, _classCallCheck3.default)(this, CharacteristicsObject);                                           //
        this['name'] = '';                                                                                    //
        this['category'] = '';                                                                                //
        this['label'] = '';                                                                                   //
        this['help'] = '';                                                                                    //
        this['image_url'] = '';                                                                               //
        this['launch_sentence'] = '';                                                                         //
    }                                                                                                         //
                                                                                                              //
    return CharacteristicsObject;                                                                             //
}();                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characteristics/methods.js                                                                     //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Characteristics = void 0;                                                                                 // 1
module.watch(require("./characteristics.js"), {                                                               // 1
    Characteristics: function (v) {                                                                           // 1
        Characteristics = v;                                                                                  // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 5
    'characteristics.upsert': function (characteristicObject) {                                               // 6
        check(characteristicObject.name, String);                                                             // 8
        return Characteristics.upsert({                                                                       // 10
            _id: characteristicObject.id                                                                      // 11
        }, {                                                                                                  // 11
            $set: {                                                                                           // 13
                name: characteristicObject.name,                                                              // 14
                image_url: characteristicObject.image_url,                                                    // 15
                launch_sentence: characteristicObject.launch_sentence,                                        // 16
                createdAt: new Date()                                                                         // 17
            }                                                                                                 // 13
        });                                                                                                   // 12
    },                                                                                                        // 20
    'characteristics.yolo': function () {                                                                     // 22
        Characteristics.insert({                                                                              // 24
            name: "informatic",                                                                               // 25
            label: "informatic",                                                                              // 26
            image_url: "/img/computing.svg",                                                                  // 27
            help: "Capacité à pousser les machines dans leurs retranchements.",                               // 28
            category: "hacking"                                                                               // 29
        });                                                                                                   // 24
        Characteristics.insert({                                                                              // 32
            name: "mechatronic",                                                                              // 33
            label: "Mécatronique",                                                                            // 34
            image_url: "/img/processor.svg",                                                                  // 35
            help: "Savoir-faire en mécanique et électronique. La robotique moins l\'informatique, en somme.",
            category: "hacking"                                                                               // 37
        });                                                                                                   // 32
        Characteristics.insert({                                                                              // 40
            name: "administratif",                                                                            // 41
            label: "Administratif",                                                                           // 42
            image_url: "/img/book-pile.svg",                                                                  // 43
            help: "Savoir exploiter une loi, refuter des charges, identifier la tête pensante d'une holding, falsifier des fiches de payes... Avec le sourire.",
            category: "hacking"                                                                               // 45
        });                                                                                                   // 40
        Characteristics.insert({                                                                              // 48
            name: "diy",                                                                                      // 49
            label: "Bricolage",                                                                               // 50
            image_url: "/img/screwdriver.svg",                                                                // 51
            help: "Comme Mc Giver ? Comme Mc Giver.",                                                         // 52
            category: "hacking"                                                                               // 53
        });                                                                                                   // 48
        Characteristics.insert({                                                                              // 56
            name: "biohack",                                                                                  // 57
            category: "hacking",                                                                              // 58
            label: "Biohack",                                                                                 // 59
            help: "Physique, chimie, bio. Et donc poisons, explosifs, adhesifs. Pour commencer.",             // 60
            image_url: "/img/molecule.svg"                                                                    // 61
        });                                                                                                   // 56
        Characteristics.insert({                                                                              // 64
            name: "illustration",                                                                             // 65
            category: "Créativité",                                                                           // 66
            label: "Illustration",                                                                            // 67
            help: "Dessiner, peindre, réaliser des images en deux dimensions.",                               // 68
            image_url: "/img/palette.svg"                                                                     // 69
        });                                                                                                   // 64
        Characteristics.insert({                                                                              // 72
            name: "audio",                                                                                    // 73
            category: "Créativité",                                                                           // 74
            label: "Audio",                                                                                   // 75
            help: "Musicien, dj ou ingénieur du son, savoir faire danser les ondes.",                         // 76
            image_url: "/img/music-spell.svg"                                                                 // 77
        });                                                                                                   // 72
        Characteristics.insert({                                                                              // 80
            name: "vidéo",                                                                                    // 81
            category: "Créativité",                                                                           // 82
            label: "Vidéo",                                                                                   // 83
            help: "Savoir créer, diffuser et éditer des vidéos, effets spéciaux compris.",                    // 84
            image_url: "/img/video-camera.svg"                                                                // 85
        });                                                                                                   // 80
        Characteristics.insert({                                                                              // 88
            name: "3darts",                                                                                   // 89
            category: "Créativité",                                                                           // 90
            label: "3D",                                                                                      // 91
            help: "L'art de modeliser, texturer et animer des images en 3 dimensions.",                       // 92
            image_url: "/img/cube.svg"                                                                        // 93
        });                                                                                                   // 88
        Characteristics.insert({                                                                              // 96
            name: "observation",                                                                              // 97
            category: "Physique",                                                                             // 98
            label: "Repérage",                                                                                // 99
            help: "Avoir le sens de l'observation et du détail.",                                             // 100
            image_url: "/img/sherlock-holmes.svg"                                                             // 101
        });                                                                                                   // 96
        Characteristics.insert({                                                                              // 104
            name: "furtivity",                                                                                // 105
            category: "Physique",                                                                             // 106
            label: "Furtivité",                                                                               // 107
            help: "Parfois, il vaut mieux passer inaperçu. Souvent en fait.",                                 // 108
            image_url: "/img/cloak-dagger.svg"                                                                // 109
        });                                                                                                   // 104
        Characteristics.insert({                                                                              // 112
            name: "resistance",                                                                               // 113
            category: "Physique",                                                                             // 114
            label: "Résistance",                                                                              // 115
            help: "Endurer ; qui endure construit sa force.",                                                 // 116
            image_url: "/img/fire-silhouette.svg"                                                             // 117
        });                                                                                                   // 112
        Characteristics.insert({                                                                              // 120
            name: "martial-arts",                                                                             // 121
            category: "Physique",                                                                             // 122
            label: "Arts Martiaux",                                                                           // 123
            help: "Le délicat art ancestral de réduire vos adversaires en bouillie. Avec élégance.",          // 124
            image_url: "/img/ninja-heroic-stance.svg"                                                         // 125
        });                                                                                                   // 120
        Characteristics.insert({                                                                              // 128
            name: "parkour",                                                                                  // 129
            category: "Physique",                                                                             // 130
            label: "Parkour",                                                                                 // 131
            help: "Mélange d'athlétisme, d'acrobatie et de gymnastique avec ce petit côté urbain chic.",      // 132
            image_url: "/img/acrobatic.svg"                                                                   // 133
        });                                                                                                   // 128
        Characteristics.insert({                                                                              // 136
            name: "letters",                                                                                  // 137
            category: "Savoirs",                                                                              // 138
            label: "Lettres",                                                                                 // 139
            help: "Les Lettres sont fleuries à qui sait se cultiver.",                                        // 140
            image_url: "/img/spell-book.svg"                                                                  // 141
        });                                                                                                   // 136
        Characteristics.insert({                                                                              // 144
            name: "economy",                                                                                  // 145
            category: "Savoirs",                                                                              // 146
            label: "Économie",                                                                                // 147
            help: "Science des actions, des fusion, des démons.",                                             // 148
            image_url: "/img/gold-stack.svg"                                                                  // 149
        });                                                                                                   // 144
        Characteristics.insert({                                                                              // 152
            name: "astronomy",                                                                                // 153
            category: "Savoirs",                                                                              // 154
            label: "Astronomie",                                                                              // 155
            help: "De tout temps les hommes... (bla bla bla) ...les étoiles. Leur poésie subtile en fait d'éternelles amies.",
            image_url: "/img/dust-cloud.svg"                                                                  // 157
        });                                                                                                   // 152
        Characteristics.insert({                                                                              // 160
            name: "sociology",                                                                                // 161
            category: "Savoirs",                                                                              // 162
            label: "Sociologie",                                                                              // 163
            help: "La science des foules, les secrets de l'Homme, l'amour des statistiques.",                 // 164
            image_url: "/img/minions.svg"                                                                     // 165
        });                                                                                                   // 160
        Characteristics.insert({                                                                              // 168
            name: "taming",                                                                                   // 169
            category: "Savoirs",                                                                              // 170
            label: "Dressage",                                                                                // 171
            help: "Faut il faire le mort ou se tenir sur un pied face à un ours ? Cette compétence vous permet de le savoir.",
            image_url: "/img/griffin-symbol.svg"                                                              // 173
        });                                                                                                   // 168
        Characteristics.insert({                                                                              // 176
            name: "histogeo",                                                                                 // 177
            category: "Savoirs",                                                                              // 178
            label: "Histoire Géo",                                                                            // 179
            help: "Je vois. Vous êtes un homme de culture vous aussi.",                                       // 180
            image_url: "/img/atlas.svg"                                                                       // 181
        });                                                                                                   // 176
        Characteristics.insert({                                                                              // 184
            name: "healing",                                                                                  // 185
            category: "Savoirs",                                                                              // 186
            label: "Médecine",                                                                                // 187
            help: "Etre capable d'exercer un diagnostic différentiel pour démasquer une sarcoïdose galopante ou un lupus. Ou retirer une balle.",
            image_url: "/img/love-injection.svg"                                                              // 189
        });                                                                                                   // 184
        Characteristics.insert({                                                                              // 192
            name: "network",                                                                                  // 193
            category: "Relations sociales",                                                                   // 194
            label: "Réseau",                                                                                  // 195
            help: "L'art de savoir à qui demander service.",                                                  // 196
            image_url: "/img/telepathy.svg"                                                                   // 197
        });                                                                                                   // 192
        Characteristics.insert({                                                                              // 200
            name: "seduction",                                                                                // 201
            category: "Relations sociales",                                                                   // 202
            label: "Séduction",                                                                               // 203
            help: "Plaire aux autres humains offre parfois des perspectives intéressantes.",                  // 204
            image_url: "/img/shining-heart.svg"                                                               // 205
        });                                                                                                   // 200
        Characteristics.insert({                                                                              // 208
            name: "body_language",                                                                            // 209
            category: "Relations sociales",                                                                   // 210
            label: "Language gestuel",                                                                        // 211
            help: "Savoir décrypter les émotions et les pensées dans les gestes.",                            // 212
            image_url: "/img/anatomy.sv"                                                                      // 213
        });                                                                                                   // 208
        Characteristics.insert({                                                                              // 216
            name: "intimidation",                                                                             // 217
            category: "Relations sociales",                                                                   // 218
            label: "Intimidation",                                                                            // 219
            help: "Effrayer pour se faire obéir. Ou pour se donner un genre.",                                // 220
            image_url: "/img/octoman.svg"                                                                     // 221
        });                                                                                                   // 216
    }                                                                                                         // 224
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"characters":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characters/server/publications.js                                                              //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Characters = void 0;                                                                                      // 1
module.watch(require("../characters.js"), {                                                                   // 1
  Characters: function (v) {                                                                                  // 1
    Characters = v;                                                                                           // 1
  }                                                                                                           // 1
}, 1);                                                                                                        // 1
Meteor.publish('characters.all', function () {                                                                // 4
  return Characters.find();                                                                                   // 5
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"characters.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characters/characters.js                                                                       //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                       //
                                                                                                              //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                              //
                                                                                                              //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }             //
                                                                                                              //
module.export({                                                                                               // 1
    Characters: function () {                                                                                 // 1
        return Characters;                                                                                    // 1
    },                                                                                                        // 1
    CharacterObject: function () {                                                                            // 1
        return CharacterObject;                                                                               // 1
    }                                                                                                         // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
    Mongo: function (v) {                                                                                     // 1
        Mongo = v;                                                                                            // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Characters = new Mongo.Collection('characters');                                                          // 4
                                                                                                              //
var CharacterObject = function () {                                                                           //
    function CharacterObject() {                                                                              //
        (0, _classCallCheck3.default)(this, CharacterObject);                                                 //
        this['name'] = '';                                                                                    //
        this['image_url'] = '';                                                                               //
        this['ethos'] = new Array();                                                                          //
        this['creaPoints'] = '';                                                                              //
        this['xpPoints'] = '';                                                                                //
        this['characteristics'] = new Array();                                                                //
    }                                                                                                         //
                                                                                                              //
    return CharacterObject;                                                                                   //
}();                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/characters/methods.js                                                                          //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Characters = void 0;                                                                                      // 1
module.watch(require("./characters.js"), {                                                                    // 1
    Characters: function (v) {                                                                                // 1
        Characters = v;                                                                                       // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 5
    'characters.upsert': function (characterObject) {                                                         // 6
        check(characterObject.name, String);                                                                  // 8
        return Characters.upsert({                                                                            // 10
            _id: characterObject.id                                                                           // 10
        }, {                                                                                                  // 10
            $set: {                                                                                           // 11
                name: characterObject.name,                                                                   // 12
                avatar: characterObject.image_url,                                                            // 13
                morality: characterObject.morality,                                                           // 14
                ethos: characterObject.ethos,                                                                 // 15
                characteristics: characterObject.characteristics,                                             // 16
                isDraft: true,                                                                                // 17
                creaPoints: characterObject.creaPoints,                                                       // 18
                xpPoints: characterObject.xpPoints ? characterObject.xpPoints : 0,                            // 19
                userId: Meteor.userId(),                                                                      // 20
                createdAt: new Date()                                                                         // 21
            }                                                                                                 // 11
        });                                                                                                   // 10
    },                                                                                                        // 24
    'characters.finalize': function (characterObject) {                                                       // 25
        check(characterObject.name, String);                                                                  // 26
        var recordresult = Characters.upsert({                                                                // 28
            _id: characterObject.id                                                                           // 28
        }, {                                                                                                  // 28
            $set: {                                                                                           // 29
                name: characterObject.name,                                                                   // 30
                avatar: characterObject.image_url,                                                            // 31
                morality: characterObject.morality,                                                           // 32
                ethos: characterObject.ethos,                                                                 // 33
                characteristics: characterObject.characteristics,                                             // 34
                isDraft: true,                                                                                // 35
                creaPoints: characterObject.creaPoints,                                                       // 36
                xpPoints: characterObject.xpPoints ? characterObject.xpPoints : 0,                            // 37
                userId: Meteor.userId(),                                                                      // 38
                createdAt: new Date()                                                                         // 39
            }                                                                                                 // 29
        });                                                                                                   // 28
        var characterId = characterObject.id;                                                                 // 43
                                                                                                              //
        if (!characterId && recordresult.insertedId) {                                                        // 44
            characterId = recordresult.insertedId;                                                            // 45
        }                                                                                                     // 46
                                                                                                              //
        if (characterId) {                                                                                    // 48
            return Characters.update({                                                                        // 49
                _id: characterId                                                                              // 49
            }, {                                                                                              // 49
                $set: {                                                                                       // 50
                    creaPoints: 0,                                                                            // 51
                    isDraft: false                                                                            // 52
                }                                                                                             // 50
            });                                                                                               // 49
        }                                                                                                     // 55
    },                                                                                                        // 56
    'characters.setSelected': function (characterId) {                                                        // 57
        check(characterId, String);                                                                           // 58
                                                                                                              //
        if (Characters.findOne(characterId)) {                                                                // 60
            //First, unselect all other characters			                                                         // 61
            Characters.update({                                                                               // 62
                userId: Meteor.userId()                                                                       // 62
            }, {                                                                                              // 62
                $set: {                                                                                       // 62
                    isSelected: false                                                                         // 62
                }                                                                                             // 62
            }, {                                                                                              // 62
                multi: true                                                                                   // 62
            }); //Then, mark provided as selected                                                             // 62
                                                                                                              //
            Characters.update(characterId, {                                                                  // 65
                $set: {                                                                                       // 65
                    isSelected: true                                                                          // 65
                }                                                                                             // 65
            });                                                                                               // 65
        }                                                                                                     // 66
    },                                                                                                        // 67
    'characters.delete': function (characterId) {                                                             // 68
        check(characterId, String);                                                                           // 69
                                                                                                              //
        if (Characters.findOne(characterId)) {                                                                // 71
            //Then, mark provided as selected                                                                 // 72
            Characters.remove(characterId);                                                                   // 73
        }                                                                                                     // 74
    }                                                                                                         // 75
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"gamelogs":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/gamelogs/server/publications.js                                                                //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Gamelogs = void 0;                                                                                        // 1
module.watch(require("../gamelogs.js"), {                                                                     // 1
    Gamelogs: function (v) {                                                                                  // 1
        Gamelogs = v;                                                                                         // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
Meteor.publish('gamelogs.all', function () {                                                                  // 4
    return Gamelogs.find();                                                                                   // 5
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"gamelogs.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/gamelogs/gamelogs.js                                                                           //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.export({                                                                                               // 1
  Gamelogs: function () {                                                                                     // 1
    return Gamelogs;                                                                                          // 1
  }                                                                                                           // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
  Mongo: function (v) {                                                                                       // 1
    Mongo = v;                                                                                                // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Gamelogs = new Mongo.Collection('gamelogs');                                                              // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/gamelogs/methods.js                                                                            //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Gamelogs = void 0;                                                                                        // 1
module.watch(require("./gamelogs.js"), {                                                                      // 1
    Gamelogs: function (v) {                                                                                  // 1
        Gamelogs = v;                                                                                         // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 5
    'gamelogs.insert': function (text, gameId) {                                                              // 6
        var isVisible = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;             // 6
        check(text, String);                                                                                  // 7
        check(gameId, String); //Logs hard debounce                                                           // 8
        //We seek for same combination text/gameId with less than one second of insertion                     // 11
        //If none only do we do the insertion                                                                 // 12
                                                                                                              //
        var now = new Date();                                                                                 // 13
        var isTooClose = false;                                                                               // 14
                                                                                                              //
        for (var _iterator = Gamelogs.find({                                                                  // 15
            gameId: gameId,                                                                                   // 15
            text: text                                                                                        // 15
        }).fetch(), _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
            var _ref;                                                                                         // 15
                                                                                                              //
            if (_isArray) {                                                                                   // 15
                if (_i >= _iterator.length) break;                                                            // 15
                _ref = _iterator[_i++];                                                                       // 15
            } else {                                                                                          // 15
                _i = _iterator.next();                                                                        // 15
                if (_i.done) break;                                                                           // 15
                _ref = _i.value;                                                                              // 15
            }                                                                                                 // 15
                                                                                                              //
            var log = _ref;                                                                                   // 15
                                                                                                              //
            if (now.getTime() - new Date(log.createdAt).getTime() < 1000) {                                   // 16
                isTooClose = true;                                                                            // 17
            }                                                                                                 // 18
        }                                                                                                     // 19
                                                                                                              //
        if (!isTooClose) {                                                                                    // 21
            return Gamelogs.insert({                                                                          // 22
                text: text,                                                                                   // 23
                gameId: gameId,                                                                               // 24
                isVisible: isVisible,                                                                         // 25
                createdAt: new Date()                                                                         // 26
            });                                                                                               // 22
        }                                                                                                     // 28
    },                                                                                                        // 29
    'gamelogs.update': function (logId, text, gameId) {                                                       // 31
        var isVisible = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;             // 31
        check(logId, String);                                                                                 // 32
        check(text, String);                                                                                  // 33
        check(gameId, String);                                                                                // 34
        return Gamelogs.update({                                                                              // 35
            _id: logId                                                                                        // 35
        }, {                                                                                                  // 35
            $set: {                                                                                           // 36
                text: text,                                                                                   // 37
                gameId: gameId,                                                                               // 38
                isVisible: isVisible                                                                          // 39
            }                                                                                                 // 36
        });                                                                                                   // 35
    },                                                                                                        // 42
    'gamelogs.set_visible': function (logId, visibility) {                                                    // 43
        check(logId, String);                                                                                 // 44
        check(visibility, Boolean);                                                                           // 45
        return Gamelogs.update({                                                                              // 46
            _id: logId                                                                                        // 46
        }, {                                                                                                  // 46
            $set: {                                                                                           // 47
                isVisible: visibility                                                                         // 48
            }                                                                                                 // 47
        });                                                                                                   // 46
    }                                                                                                         // 51
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"games":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/games/server/publications.js                                                                   //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Games = void 0,                                                                                           // 1
    CharactersInGames = void 0;                                                                               // 1
module.watch(require("../games.js"), {                                                                        // 1
    Games: function (v) {                                                                                     // 1
        Games = v;                                                                                            // 1
    },                                                                                                        // 1
    CharactersInGames: function (v) {                                                                         // 1
        CharactersInGames = v;                                                                                // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
Meteor.publish('games.all', function () {                                                                     // 5
    return Games.find();                                                                                      // 6
});                                                                                                           // 7
Meteor.publish('characters_in_games.all', function () {                                                       // 9
    var _this = this;                                                                                         // 9
                                                                                                              //
    //When user leaves                                                                                        // 11
    this._session.socket.on("close", Meteor.bindEnvironment(function () {                                     // 12
        return CharactersInGames.upsert({                                                                     // 13
            userId: _this.userId                                                                              // 13
        }, {                                                                                                  // 13
            $set: {                                                                                           // 14
                isCurrentlyIn: false                                                                          // 15
            }                                                                                                 // 14
        });                                                                                                   // 13
    }));                                                                                                      // 18
                                                                                                              //
    return CharactersInGames.find();                                                                          // 20
});                                                                                                           // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"games.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/games/games.js                                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                       //
                                                                                                              //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                              //
                                                                                                              //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }             //
                                                                                                              //
module.export({                                                                                               // 1
    Games: function () {                                                                                      // 1
        return Games;                                                                                         // 1
    },                                                                                                        // 1
    CharactersInGames: function () {                                                                          // 1
        return CharactersInGames;                                                                             // 1
    },                                                                                                        // 1
    GameObject: function () {                                                                                 // 1
        return GameObject;                                                                                    // 1
    }                                                                                                         // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
    Mongo: function (v) {                                                                                     // 1
        Mongo = v;                                                                                            // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Characters = void 0;                                                                                      // 1
module.watch(require("../characters/characters.js"), {                                                        // 1
    Characters: function (v) {                                                                                // 1
        Characters = v;                                                                                       // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Games = new Mongo.Collection('games');                                                                    // 5
var CharactersInGames = new Mongo.Collection('characters_in_games');                                          // 6
                                                                                                              //
var GameObject = function () {                                                                                //
    function GameObject() {                                                                                   //
        (0, _classCallCheck3.default)(this, GameObject);                                                      //
    }                                                                                                         //
                                                                                                              //
    return GameObject;                                                                                        //
}();                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/games/methods.js                                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Games = void 0,                                                                                           // 1
    GameObject = void 0,                                                                                      // 1
    CharactersInGames = void 0;                                                                               // 1
module.watch(require("./games.js"), {                                                                         // 1
    Games: function (v) {                                                                                     // 1
        Games = v;                                                                                            // 1
    },                                                                                                        // 1
    GameObject: function (v) {                                                                                // 1
        GameObject = v;                                                                                       // 1
    },                                                                                                        // 1
    CharactersInGames: function (v) {                                                                         // 1
        CharactersInGames = v;                                                                                // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
var Gamelogs = void 0;                                                                                        // 1
module.watch(require("../gamelogs/gamelogs.js"), {                                                            // 1
    Gamelogs: function (v) {                                                                                  // 1
        Gamelogs = v;                                                                                         // 1
    }                                                                                                         // 1
}, 3);                                                                                                        // 1
Meteor.methods({                                                                                              // 6
    'games.upsert': function (gameObject) {                                                                   // 7
        var user = Meteor.users.findOne(Meteor.userId());                                                     // 9
        check(user.username, String);                                                                         // 10
        check(gameObject.title, String);                                                                      // 11
        return Games.upsert({                                                                                 // 13
            _id: gameObject.id                                                                                // 13
        }, {                                                                                                  // 13
            $set: {                                                                                           // 14
                title: gameObject.title,                                                                      // 15
                description: gameObject.description,                                                          // 16
                socialContract: gameObject.socialContract,                                                    // 17
                fantasyLevel: gameObject.fantasyLevel,                                                        // 18
                times: gameObject.times,                                                                      // 19
                userId: Meteor.userId(),                                                                      // 20
                userName: user.username,                                                                      // 21
                isOpen: false,                                                                                // 22
                createdAt: new Date()                                                                         // 23
            }                                                                                                 // 14
        });                                                                                                   // 13
    },                                                                                                        // 26
    'games.join': function (gameId, characterId) {                                                            // 27
        check(gameId, String);                                                                                // 28
        check(characterId, String);                                                                           // 29
        var gameUserUnicity = gameId + Meteor.userId();                                                       // 30
        return CharactersInGames.upsert({                                                                     // 32
            gameUserUnicity: gameUserUnicity                                                                  // 32
        }, {                                                                                                  // 32
            $set: {                                                                                           // 33
                characterId: characterId,                                                                     // 34
                gameId: gameId,                                                                               // 35
                gameUserUnicity: gameUserUnicity,                                                             // 36
                isCurrentlyIn: true,                                                                          // 37
                isMJ: false,                                                                                  // 38
                userId: Meteor.userId(),                                                                      // 39
                createdAt: new Date()                                                                         // 40
            }                                                                                                 // 33
        });                                                                                                   // 32
    },                                                                                                        // 43
    'games.leave': function (userId) {                                                                        // 44
        check(userId, String);                                                                                // 45
        return CharactersInGames.upsert({                                                                     // 46
            userId: userId                                                                                    // 46
        }, {                                                                                                  // 46
            $set: {                                                                                           // 47
                isCurrentlyIn: false                                                                          // 48
            }                                                                                                 // 47
        });                                                                                                   // 46
    },                                                                                                        // 51
    'games.open': function (gameId) {                                                                         // 52
        check(gameId, String);                                                                                // 53
        var gameUserUnicity = gameId + Meteor.userId();                                                       // 54
        CharactersInGames.upsert({                                                                            // 56
            gameUserUnicity: gameUserUnicity                                                                  // 56
        }, {                                                                                                  // 56
            $set: {                                                                                           // 57
                characterId: null,                                                                            // 58
                gameId: gameId,                                                                               // 59
                gameUserUnicity: gameUserUnicity,                                                             // 60
                isCurrentlyIn: true,                                                                          // 61
                isMJ: true,                                                                                   // 62
                userId: Meteor.userId(),                                                                      // 63
                createdAt: new Date()                                                                         // 64
            }                                                                                                 // 57
        });                                                                                                   // 56
        return Games.update({                                                                                 // 68
            _id: gameId                                                                                       // 68
        }, {                                                                                                  // 68
            $set: {                                                                                           // 68
                isOpen: true                                                                                  // 68
            }                                                                                                 // 68
        });                                                                                                   // 68
    },                                                                                                        // 69
    'games.delete': function (gameId) {                                                                       // 70
        check(gameId, String);                                                                                // 71
                                                                                                              //
        if (Games.findOne(gameId)) {                                                                          // 73
            //Then, mark provided as selected                                                                 // 74
            Games.remove(gameId);                                                                             // 75
        }                                                                                                     // 76
    }                                                                                                         // 77
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"links":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/links/server/publications.js                                                                   //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Links = void 0;                                                                                           // 1
module.watch(require("../links.js"), {                                                                        // 1
  Links: function (v) {                                                                                       // 1
    Links = v;                                                                                                // 1
  }                                                                                                           // 1
}, 1);                                                                                                        // 1
Meteor.publish('links.all', function () {                                                                     // 6
  return Links.find();                                                                                        // 7
});                                                                                                           // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"links.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/links/links.js                                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.export({                                                                                               // 1
  Links: function () {                                                                                        // 1
    return Links;                                                                                             // 1
  }                                                                                                           // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
  Mongo: function (v) {                                                                                       // 1
    Mongo = v;                                                                                                // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Links = new Mongo.Collection('links');                                                                    // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/links/methods.js                                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
  check: function (v) {                                                                                       // 1
    check = v;                                                                                                // 1
  }                                                                                                           // 1
}, 1);                                                                                                        // 1
var Links = void 0;                                                                                           // 1
module.watch(require("./links.js"), {                                                                         // 1
  Links: function (v) {                                                                                       // 1
    Links = v;                                                                                                // 1
  }                                                                                                           // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 7
  'links.insert': function (title, url) {                                                                     // 8
    check(url, String);                                                                                       // 9
    check(title, String);                                                                                     // 10
    return Links.insert({                                                                                     // 12
      url: url,                                                                                               // 13
      title: title,                                                                                           // 14
      createdAt: new Date()                                                                                   // 15
    });                                                                                                       // 12
  }                                                                                                           // 17
});                                                                                                           // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"notifications":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/notifications/server/publications.js                                                           //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Notifications = void 0;                                                                                   // 1
module.watch(require("../notifications.js"), {                                                                // 1
    Notifications: function (v) {                                                                             // 1
        Notifications = v;                                                                                    // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
Meteor.publish('notifications.all', function () {                                                             // 4
    var cursor = Notifications.find();                                                                        // 6
    Notifications.update({                                                                                    // 8
        userId: 'Z9EJTmh5vTd6ScxLH'                                                                           // 8
    }, {                                                                                                      // 8
        $addToSet: {                                                                                          // 9
            title: "Titre de Notification"                                                                    // 9
        }                                                                                                     // 9
    }, {                                                                                                      // 8
        multi: true                                                                                           // 9
    });                                                                                                       // 9
    return cursor;                                                                                            // 11
});                                                                                                           // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/notifications/methods.js                                                                       //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Notifications = void 0;                                                                                   // 1
module.watch(require("./notifications.js"), {                                                                 // 1
    Notifications: function (v) {                                                                             // 1
        Notifications = v;                                                                                    // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
var Gamelogs = void 0;                                                                                        // 1
module.watch(require("../gamelogs/gamelogs.js"), {                                                            // 1
    Gamelogs: function (v) {                                                                                  // 1
        Gamelogs = v;                                                                                         // 1
    }                                                                                                         // 1
}, 3);                                                                                                        // 1
Meteor.methods({                                                                                              // 6
    'notification.send': function (text) {                                                                    // 7
        var title = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                   // 7
        var type = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'basic';               // 7
        var isGlobal = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;             // 7
        var datasPayload = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};            // 7
        var userId = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : "";                  // 7
        check(text, String);                                                                                  // 8
        check(isGlobal, Boolean);                                                                             // 9
        check(userId, String);                                                                                // 10
        return Notifications.insert({                                                                         // 12
            text: text,                                                                                       // 13
            title: title,                                                                                     // 14
            type: type,                                                                                       // 15
            isGlobal: isGlobal,                                                                               // 16
            userId: userId,                                                                                   // 17
            datas: datasPayload,                                                                              // 18
            createdAt: new Date()                                                                             // 19
        });                                                                                                   // 12
    },                                                                                                        // 21
    'notification.remove': function (notifId) {                                                               // 23
        check(notifId, String);                                                                               // 24
        return Notifications.remove({                                                                         // 26
            _id: notifId                                                                                      // 27
        });                                                                                                   // 26
    }                                                                                                         // 29
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/notifications/notifications.js                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.export({                                                                                               // 1
  Notifications: function () {                                                                                // 1
    return Notifications;                                                                                     // 1
  }                                                                                                           // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
  Mongo: function (v) {                                                                                       // 1
    Mongo = v;                                                                                                // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Notifications = new Mongo.Collection('notifications');                                                    // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"skills":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/skills/server/publications.js                                                                  //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Skills = void 0;                                                                                          // 1
module.watch(require("../skills.js"), {                                                                       // 1
    Skills: function (v) {                                                                                    // 1
        Skills = v;                                                                                           // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
Meteor.publish('skills.all', function () {                                                                    // 4
    return Skills.find();                                                                                     // 5
});                                                                                                           // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/skills/methods.js                                                                              //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Skills = void 0;                                                                                          // 1
module.watch(require("./skills.js"), {                                                                        // 1
    Skills: function (v) {                                                                                    // 1
        Skills = v;                                                                                           // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 5
    'skills.upsert': function (skillObject) {                                                                 // 6
        check(skillObject.name, String);                                                                      // 8
        check(skillObject.label, String);                                                                     // 9
        return Skills.upsert({                                                                                // 11
            _id: skillObject.id                                                                               // 11
        }, {                                                                                                  // 11
            $set: {                                                                                           // 12
                name: skillObject.name,                                                                       // 13
                label: skillObject.label,                                                                     // 14
                level: skillObject.level,                                                                     // 15
                category: skillObject.category,                                                               // 16
                imageUrl: skillObject.imageUrl,                                                               // 17
                description: skillObject.description,                                                         // 18
                saidWhenDone: skillObject.saidWhenDone,                                                       // 19
                parentsAND: skillObject.parentsAND,                                                           // 20
                parentsOR: skillObject.parentsOR,                                                             // 21
                createdAt: new Date()                                                                         // 22
            }                                                                                                 // 12
        });                                                                                                   // 11
    },                                                                                                        // 25
    'skills.delete': function (id) {                                                                          // 26
        check(id, String);                                                                                    // 27
        return Skills.remove(id);                                                                             // 28
    }                                                                                                         // 29
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"skills.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/skills/skills.js                                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                       //
                                                                                                              //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                              //
                                                                                                              //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }             //
                                                                                                              //
module.export({                                                                                               // 1
    Skills: function () {                                                                                     // 1
        return Skills;                                                                                        // 1
    },                                                                                                        // 1
    SkillsObject: function () {                                                                               // 1
        return SkillsObject;                                                                                  // 1
    }                                                                                                         // 1
});                                                                                                           // 1
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
    Mongo: function (v) {                                                                                     // 1
        Mongo = v;                                                                                            // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var Skills = new Mongo.Collection('skills');                                                                  // 3
                                                                                                              //
var SkillsObject = function () {                                                                              //
    function SkillsObject() {                                                                                 //
        (0, _classCallCheck3.default)(this, SkillsObject);                                                    //
        this['name'] = '';                                                                                    //
        this['label'] = '';                                                                                   //
        this['level'] = '';                                                                                   //
        this['imageUrl'] = '';                                                                                //
        this['category'] = '';                                                                                //
        this['parentsAND'] = '';                                                                              //
        this['parentsOR'] = '';                                                                               //
        this['description'] = '';                                                                             //
        this['saidWhenDone'] = '';                                                                            //
    }                                                                                                         //
                                                                                                              //
    return SkillsObject;                                                                                      //
}();                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"users":{"server":{"publications.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/users/server/publications.js                                                                   //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
Meteor.publish('users.all', function () {                                                                     // 3
  return Meteor.users.find({}, {                                                                              // 4
    fields: {                                                                                                 // 4
      'username': 1                                                                                           // 4
    }                                                                                                         // 4
  });                                                                                                         // 4
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/users/methods.js                                                                               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
    Meteor: function (v) {                                                                                    // 1
        Meteor = v;                                                                                           // 1
    }                                                                                                         // 1
}, 0);                                                                                                        // 1
var check = void 0;                                                                                           // 1
module.watch(require("meteor/check"), {                                                                       // 1
    check: function (v) {                                                                                     // 1
        check = v;                                                                                            // 1
    }                                                                                                         // 1
}, 1);                                                                                                        // 1
var Users = void 0;                                                                                           // 1
module.watch(require("./users.js"), {                                                                         // 1
    Users: function (v) {                                                                                     // 1
        Users = v;                                                                                            // 1
    }                                                                                                         // 1
}, 2);                                                                                                        // 1
Meteor.methods({                                                                                              // 5
    'user.update': function (username, email) {                                                               // 6
        check(username, String); //@TODO check that it's a mail                                               // 7
                                                                                                              //
        check(email, String);                                                                                 // 9
        return Meteor.users.update({                                                                          // 11
            _id: Meteor.userId()                                                                              // 12
        }, {                                                                                                  // 12
            $set: {                                                                                           // 13
                "username": username,                                                                         // 13
                "emails.0.address": email                                                                     // 13
            }                                                                                                 // 13
        });                                                                                                   // 13
    }                                                                                                         // 14
});                                                                                                           // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/api/users/users.js                                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Mongo = void 0;                                                                                           // 1
module.watch(require("meteor/mongo"), {                                                                       // 1
  Mongo: function (v) {                                                                                       // 1
    Mongo = v;                                                                                                // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/startup/both/index.js                                                                              //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
// Import modules used by both client and server through a single index entry point                           // 1
// e.g. useraccounts configuration file.                                                                      // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixtures.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/startup/server/fixtures.js                                                                         //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var Meteor = void 0;                                                                                          // 1
module.watch(require("meteor/meteor"), {                                                                      // 1
  Meteor: function (v) {                                                                                      // 1
    Meteor = v;                                                                                               // 1
  }                                                                                                           // 1
}, 0);                                                                                                        // 1
var Links = void 0;                                                                                           // 1
module.watch(require("../../api/links/links.js"), {                                                           // 1
  Links: function (v) {                                                                                       // 1
    Links = v;                                                                                                // 1
  }                                                                                                           // 1
}, 1);                                                                                                        // 1
Meteor.startup(function () {                                                                                  // 6
  // if the Links collection is empty                                                                         // 7
  if (Links.find().count() === 0) {                                                                           // 8
    var data = [{                                                                                             // 9
      title: 'Do the Tutorial',                                                                               // 11
      url: 'https://www.meteor.com/try',                                                                      // 12
      createdAt: new Date()                                                                                   // 13
    }, {                                                                                                      // 10
      title: 'Follow the Guide',                                                                              // 16
      url: 'http://guide.meteor.com',                                                                         // 17
      createdAt: new Date()                                                                                   // 18
    }, {                                                                                                      // 15
      title: 'Read the Docs',                                                                                 // 21
      url: 'https://docs.meteor.com',                                                                         // 22
      createdAt: new Date()                                                                                   // 23
    }, {                                                                                                      // 20
      title: 'Discussions',                                                                                   // 26
      url: 'https://forums.meteor.com',                                                                       // 27
      createdAt: new Date()                                                                                   // 28
    }];                                                                                                       // 25
    data.forEach(function (link) {                                                                            // 32
      return Links.insert(link);                                                                              // 32
    });                                                                                                       // 32
  }                                                                                                           // 33
});                                                                                                           // 34
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/startup/server/index.js                                                                            //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.watch(require("./fixtures.js"));                                                                       // 1
module.watch(require("./register-api.js"));                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// imports/startup/server/register-api.js                                                                     //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.watch(require("../../api/gamelogs/methods.js"));                                                       // 1
module.watch(require("../../api/gamelogs/server/publications.js"));                                           // 1
module.watch(require("../../api/links/methods.js"));                                                          // 1
module.watch(require("../../api/links/server/publications.js"));                                              // 1
module.watch(require("../../api/games/methods.js"));                                                          // 1
module.watch(require("../../api/games/server/publications.js"));                                              // 1
module.watch(require("../../api/characters/methods.js"));                                                     // 1
module.watch(require("../../api/characters/server/publications.js"));                                         // 1
module.watch(require("../../api/characteristics/methods.js"));                                                // 1
module.watch(require("../../api/characteristics/server/publications.js"));                                    // 1
module.watch(require("../../api/skills/methods.js"));                                                         // 1
module.watch(require("../../api/skills/server/publications.js"));                                             // 1
module.watch(require("../../api/notifications/methods.js"));                                                  // 1
module.watch(require("../../api/notifications/server/publications.js"));                                      // 1
module.watch(require("../../api/users/methods.js"));                                                          // 1
module.watch(require("../../api/users/server/publications.js"));                                              // 1
module.watch(require("../../api/users/server/publications.js"));                                              // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// server/main.js                                                                                             //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
module.watch(require("/imports/startup/server"));                                                             // 1
module.watch(require("/imports/startup/both"));                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
