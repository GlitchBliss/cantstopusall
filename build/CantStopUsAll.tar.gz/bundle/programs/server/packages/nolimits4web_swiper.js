(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nolimits4web:swiper'] = {};

})();
